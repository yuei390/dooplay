<?php 
/*
Template Name: DT - Favorites page
*/
get_header(); 

	// function theme

get_footer();