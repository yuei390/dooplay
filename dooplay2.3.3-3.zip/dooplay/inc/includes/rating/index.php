<?php
# Silence is golden.
