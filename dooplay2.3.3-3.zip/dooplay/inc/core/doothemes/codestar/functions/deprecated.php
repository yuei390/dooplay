<?php if(!defined('ABSPATH')){ die; }
/**
 * Check for google font
 * @since 1.0.0
 * @deprecated 1.0.0
 */
function cs_is_googe_font() {
    _deprecated_function( __FUNCTION__, '1.0.0' );
}



/**
 * Safe web fonts
 * @since 1.0.0
 * @deprecated 1.0.0
 */
function cs_get_websafe_fonts() {
    _deprecated_function( __FUNCTION__, '1.0.0' );
}
